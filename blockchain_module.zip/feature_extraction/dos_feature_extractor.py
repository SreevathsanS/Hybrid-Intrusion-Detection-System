import subprocess
import pandas as pd
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
print("EXTRACTING DoS (SYN FLOOD) FEATURES FROM VICTIM....")

#---------------------------------------------------
# CONFIG
#---------------------------------------------------

UBUNTU_IP = "192.168.32.128"
UBUNTU_USER = "testuser"

OUTPUT_CSV = os.path.join(
    BASE_DIR,
    "..",
    "data",
    "dos_feature_extractor.csv"
)


#---------------------------------------
# SSH COMMAND
# Count SYN-RECV Connections (halso-open TCP)
#---------------------------------------------------

remote_command = (
    "bash -lc \""
    "(ss -ant state syn-recv 2>/dev/null | wc -l) || "
    "(netstat -atn 2>/dev/null | grep SYN_RECV | wc -l) || "
    "echo 0"
    "\""
)

ssh_command = [
    "ssh",
    f"{UBUNTU_USER}@{UBUNTU_IP}",
    remote_command
]
#---------------------------------------------------
# EXECUTING SSH COMMAND
#---------------------------------------------------

try:
    output = subprocess.check_output(
        ssh_command,
        text=True
    ).strip()

except subprocess.CalledProcessError:
    output = "0" 
    
try:
    syn_count = int(output)
except ValueError:
    syn_count = 0

print(f"HALF OPEN TCP CONNECTION (SYN_RECV): {syn_count}")

#---------------------------------------------------
# BUILD ML FEATURE VECTOR
#---------------------------------------------------
# HIGH SYN_RECV Count indicates SYN flood

features = {
    "duration": 10,
    "protocol_type":"tcp",
    "service":"HTTP",
    "flag":"S0",
    "src_bytes":0,
    "dst_bytes":0,
    "count":syn_count,
    "srv_count":syn_count,
    "dst_host_count":syn_count,
    "dst_host_srv_count":syn_count,
    "dst_host_same_srv_rate":1.0 if syn_count > 0 else 0.0,
    "dst_host_diff_srv_rate":0.0
}

df = pd.DataFrame([features])
df.to_csv(OUTPUT_CSV,index=False)

print(f"DoS Features extracted to {OUTPUT_CSV}")

