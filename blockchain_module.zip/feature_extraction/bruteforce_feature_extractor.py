import subprocess
import pandas as pd
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
#-----------------------------------
# UBUNTU CONFIG
#-----------------------------------

UBUNTU_IP = "192.168.32.128"
UBUNTU_USER = "testuser"
OUTPUT_CSV = "../data/bruteforce_features.csv"


OUTPUT_CSV = os.path.join(
    BASE_DIR,
    "..",
    "data",
    "bruteforce_features.csv"
)

#-----------------------------------
# FETCH LOG VIA SSH
#-----------------------------------

command = [
    "ssh",
    f"{UBUNTU_USER}@{UBUNTU_IP}",
    "grep -a 'Failed password' /var/log/auth.log || true"
]


print("EXTRACTING THE BRUTEFORCE LOG FROM VICTIM....")

# -----------------------------
# EXECUTE SSH COMMAND
# -----------------------------
try:
    output = subprocess.check_output(
        command,
        text=True
    )
except subprocess.CalledProcessError as e:
    # This should NOT happen now, but just in case
    output = e.output or ""

lines = output.strip().splitlines() if output.strip() else []
failed_count = len(lines)
print(f" Failed SSH attempts: {failed_count}")

#-----------------------------------
# BUILD FEATURE RECORD 
#-----------------------------------

features = {
    "duration": 60,
    "protocol_type": "tcp",
    "service": "ssh",
    "flag": "S0",
    "count": failed_count,
    "srv_count": failed_count,
    "dst_host_count": failed_count,
    "dst_host_srv_count": failed_count,
    "dst_host_same_srv_rate": 1.0,
    "dst_host_diff_srv_rate": 0.0
}

df = pd.DataFrame([features])
df.to_csv(OUTPUT_CSV, index=False)

print(f" FEATURE FILE WRITTEN to {OUTPUT_CSV}")

