import subprocess
import sys
import os
from blockchain_module.config.attack_config import ATTACK_SCENARIO

print("\n================================================")
print(" IDS HYBRID SYSTEM STARTING")
print("\n================================================")

#------------------------------------------
# STEP 1 DEPLOY THE SMART CONTRACT
#------------------------------------------

print("[1] DEPLOYING SMART CONTRACT...........")

deploy_process = subprocess.check_output(
    [sys.executable,"blockchain_module/scripts/deploy_contract.py"],
    text=True

)
print(deploy_process)

#------------------------------------------
# PARSE DEPLOY OUTPUT
#------------------------------------------

deploy_account = None
contract_account = None

for line in deploy_process.splitlines():
    if line.startswith("DEPLOYED_ACCOUNT="):
        deploy_account = line.split("=")[1].strip()
    if line.startswith("CONTRACT_ADDRESS="):
        contract_account = line.split("=")[1].strip()

if not deploy_account or not contract_account:
    raise RuntimeError("Failed to reterive the blockchain deploymentb details")

print(f"Account: {deploy_account}")
print(f"Contract: {contract_account}")

os.environ["DEPLOYED_ACCOUNT"] = deploy_account
os.environ["CONTRACT_ADDRESS"] = contract_account

#------------------------------------------
# Feature Extraction
#------------------------------------------
print("[2] Extracting Features")

if ATTACK_SCENARIO == "DOS":
    subprocess.run(
        [sys.executable,"feature_extraction/dos_feature_extractor.py"],
        check=True
    )

elif ATTACK_SCENARIO == "BRUTEFORCE":
    subprocess.run(
        [sys.executable,"feature_extraction/bruteforce_feature_extractor.py"],
        check=True
    )
else:
    raise ValueError("Invalid ATTACK SCENARIO in Config")

#------------------------------------------
# ML PREDICTION AND BLOCKCHAIN
#------------------------------------------

print("\n[3] Running ML Prediction + Blockchain Logging...")

subprocess.run(
    [sys.executable,"blockchain_module/scripts/sl.py"],
    check=True
)


print("\n================================================")
print("IDS PIPELINE COMPLETED")
print("\n================================================")
