import pickle
import pandas as pd
import joblib

# -----------------------------
# LOAD MODEL & SCALER
# -----------------------------
with open("ids_xgboost_gpu_colab.pkl", "rb") as f:
    model = pickle.load(f)

with open("scalar.pkl", "rb") as f:
    scaler = joblib.load(f)

# -----------------------------
# PREDICTION FUNCTION
# -----------------------------
def predict_intrusion(input_row: pd.DataFrame):
    """
    input_row: DataFrame with ONE network traffic row
    """

    scaled_input = scaler.transform(input_row)
    prediction = model.predict(scaled_input)[0]

    if prediction == 0:
        return "Normal", "Benign"
    else:
        return "Attack", "Malicious"
