import pickle
import pandas as pd
import joblib
import os

print("Loading model assets...")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

model = pickle.load(open(os.path.join(BASE_DIR, "models/model.pkl"), "rb"))
model.set_params(predictor="cpu_predictor")

scaler = joblib.load(os.path.join(BASE_DIR, "models/scaler.pkl"))
feature_columns = joblib.load(os.path.join(BASE_DIR, "models/feature_columns.pkl"))


def predict_intrusion(raw_df: pd.DataFrame):
    """
    raw_df: DataFrame with raw input features (1 row)
    """

    # 1️⃣ Reindex to training feature space
    df = raw_df.reindex(columns=feature_columns, fill_value=0)

    # 2️⃣ Scale
    scaled = scaler.transform(df)

    # 3️⃣ Predict
    pred = model.predict(scaled)[0]

    if pred == 0:
        return "Normal", "Benign"
    else:
        return "Attack", "Malicious"
